import pymysql
try:
    con=pymysql.connect(host='bbmvazvhyi77kqfavmmj-mysql.services.clever-cloud.com',user='u3mdqqoifgjhsh3t',password='g30zQ8cOYH52daH7Olmj',database='bbmvazvhyi77kqfavmmj')
    curs=con.cursor()

    #using a VIEW to get list of all books along with categories from different table
    #CREATE VIEW AllBooks AS SELECT B.BookCode, C.CategoryName, B.BookName, B.Author, B.Publication, B.Edition, B.Price from Books B inner join BookCategory C where B.BookCategoryId = C.Id and B.IsActive = 1
    
    curs.execute("select * from AllBooks")
    #curs.execute("select * from Books")
    data=curs.fetchall()
    if(len(data) > 0):
        print('Books are available!')
        for rec in data:
            print(rec)
    else:
        print('No books are available to show!')
except Exception as e:
    print('Error : ',e)
con.close()