from datetime import datetime
import pymysql
con=pymysql.connect(host='bbmvazvhyi77kqfavmmj-mysql.services.clever-cloud.com',user='u3mdqqoifgjhsh3t',password='g30zQ8cOYH52daH7Olmj',database='bbmvazvhyi77kqfavmmj')
curs=con.cursor()
try:    
    curs.execute("select Id,CategoryName from BookCategory where IsActive=1")
    listOfCategories=curs.fetchall()
    if(len(listOfCategories) > 0):
        print('Available Categories:\n')
        for rec in listOfCategories:
            print(rec[1])

    category = None
    categoryId = None
    while(categoryId == None):
        category=input('\nSelect category for book from given list: ')
        for record in listOfCategories:
            if(record[1].lower() == category.lower()):
                categoryId=record[0]
                print("Selected Category: %s" %category)
                print("Selected Category Id: %s" %categoryId)
                break
        if(categoryId == None):
            print("%s is not present. Please select another one." %category) 
        else:
            break         
    bookName=input('Enter Book Title: ')
    author=input('Enter Auther Name: ')
    publication=input('Enter Publisher: ')
    edition=input('Enter Edition: ')
    price=float(input('Enter Price : '))
    createdDate = datetime.now()
    isActive = bool(True);

    query = "INSERT INTO Books(BookName,BookCategoryId,Author,Publication,Edition,Price,IsActive,CreatedDate) VALUES ('%s',%d,'%s','%s','%s',%.2f,%r,'%s');"
    curs.execute(query %(bookName,categoryId,author,publication,edition,price,isActive,createdDate))
    con.commit()
    print('Book has been added in collection!')    
except Exception as e:
    print('Error : ',e)
con.close()