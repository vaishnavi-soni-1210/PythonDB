import pymysql
try:
    con=pymysql.connect(host='bbmvazvhyi77kqfavmmj-mysql.services.clever-cloud.com',user='u3mdqqoifgjhsh3t',password='g30zQ8cOYH52daH7Olmj',database='bbmvazvhyi77kqfavmmj')
    curs=con.cursor()

    #using a VIEW to get list of all books along with categories from different table
    #CREATE VIEW AllBooks AS SELECT B.BookCode, C.CategoryName, B.BookName, B.Author, B.Publication, B.Edition, B.Price from Books B inner join BookCategory C where B.BookCategoryId = C.Id and B.IsActive = 1
    
    bookCode = int(input("Enter Book Code: "))
    curs.execute("select * from AllBooks where BookCode=%d" %bookCode)
    data=curs.fetchone()
    if(data != None and len(data) > 0):
        print("Book Code: %s" %data[0])
        print("Category: %s" %data[1])
        print("Book Title: %s" %data[2])
        print("Author: %s" %data[3])
        print("Publication: %s" %data[4])
        print("Edition: %s" %data[5])
        print("Price: %.2f" %data[6])
        print("Review: %s" %data[7])
    else:
        print("No book found in collection with the given code.")
except Exception as e:
    print('Error : ',e)
con.close()