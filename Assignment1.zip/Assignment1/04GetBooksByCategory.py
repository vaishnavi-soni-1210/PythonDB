import pymysql
try:
    con=pymysql.connect(host='bbmvazvhyi77kqfavmmj-mysql.services.clever-cloud.com',user='u3mdqqoifgjhsh3t',password='g30zQ8cOYH52daH7Olmj',database='bbmvazvhyi77kqfavmmj')
    curs=con.cursor()

    #print all categories
    curs.execute("select Id,CategoryName from BookCategory where IsActive=1")
    listOfCategories=curs.fetchall()
    if(len(listOfCategories) > 0):
        print('Available Categories:\n')
        for rec in listOfCategories:
            print(rec[1])

    #ask user to select category
    category = None
    categoryId = None
    while(categoryId == None):
        category=input('\nSelect category for book from given list: ')
        for record in listOfCategories:
            if(record[1].lower() == category.lower()):
                categoryId=record[0]
                print("Selected Category: %s" %category)
                break
        if(categoryId == None):
            print("%s is not present. Please select another one." %category) 
        else:
            break         
    
    curs.execute("select BookCode,BookName,Author,Price from Books where BookCategoryId=%d and IsActive=1" %categoryId)
    data=curs.fetchall()
    if(len(data) > 0):
        print('Books for chosen category are: ')
        for rec in data:
            print(rec)
    else:
        print('No books are available for chosen category!')
except Exception as e:
    print('Error : ',e)
con.close()