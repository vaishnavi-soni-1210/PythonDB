import pymysql
try:
    con=pymysql.connect(host='bbmvazvhyi77kqfavmmj-mysql.services.clever-cloud.com',user='u3mdqqoifgjhsh3t',password='g30zQ8cOYH52daH7Olmj',database='bbmvazvhyi77kqfavmmj')
    curs=con.cursor()

    bookCode = int(input("Enter Book Code: "))
    newPrice = float(input("Enter New Price: "))
    while(newPrice <=0):
        print("Invalid Price! Please try again.")
        newPrice = float(input("Enter New Price: "))
    result = curs.execute("Update Books set Price = %.2f where BookCode=%d" %(newPrice,bookCode))
    con.commit()

    if(result > 0):
        print('Successfully update the price for Book Code: %d.' %(bookCode))
    else:
        print('No book exists with the given Code!')
except Exception as e:
    print('Error : ',e)
con.close()