import pymysql
try:
    con=pymysql.connect(host='bbmvazvhyi77kqfavmmj-mysql.services.clever-cloud.com',user='u3mdqqoifgjhsh3t',password='g30zQ8cOYH52daH7Olmj',database='bbmvazvhyi77kqfavmmj')
    curs=con.cursor()

    #ask user to select author and publication
    author = None
    publication = None
    while(author == None and publication == None):
        author=input('Enter Author Name: ')
        publication=input('Enter Publication: ')
   
    #Author = J. K. Rowling
    #Publication = Bloomsbury

    curs.execute("select BookCode,CategoryName,BookName,Price from AllBooks where Author='%s' and Publication='%s'" %(author,publication))
    data=curs.fetchall()
    if(len(data) > 0):
        print('Books for chosen Author-Publication combination: ')
        for rec in data:
            print(rec)
    else:
        print('No books are available for chosen Author-Publication combination!')  
    
except Exception as e:
    print('Error : ',e)
con.close()