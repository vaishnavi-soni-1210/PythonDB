import pymysql
try:
    con=pymysql.connect(host='bbmvazvhyi77kqfavmmj-mysql.services.clever-cloud.com',user='u3mdqqoifgjhsh3t',password='g30zQ8cOYH52daH7Olmj',database='bbmvazvhyi77kqfavmmj')
    curs=con.cursor()

    bookCode = int(input("Enter Book Code: "))
    review = None
    while(review == None):
        review = input("Enter Review: ")
    result = curs.execute("Update Books set Review = '%s' where BookCode=%d" %(review,bookCode))
    con.commit()

    if(result > 0):
        print('Successfully added the review for Book Code: %d.' %(bookCode))
    else:
        print('No book exists with the given Code!')
        
except Exception as e:
    print('Error : ',e)
con.close()