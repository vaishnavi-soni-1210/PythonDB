import pymysql
con=pymysql.connect(host='bbmvazvhyi77kqfavmmj-mysql.services.clever-cloud.com',user='u3mdqqoifgjhsh3t',password='g30zQ8cOYH52daH7Olmj',database='bbmvazvhyi77kqfavmmj')
curs=con.cursor()
try:   
    curs.execute("select Id,CategoryName from BookCategory where IsActive=1")
    data=curs.fetchall()
    if(len(data) > 0):
        print('Available Categories: \n')
        for rec in data:
            print(rec[1])
    else:
        print('No categories are available to show!')   
except Exception as e:
    print('Error : ',e)
con.close()